# Databricks notebook source
from tests.test_booking_etl import test_etl_pipeline

# COMMAND ----------

# run test 
test_etl_pipeline()