# Databricks notebook source
from src.booking_etl import extract_tour_operator_bookings 
from pyspark.sql.types import (
    StructType, StructField, StringType, BooleanType, IntegerType, DateType
)

# COMMAND ----------

input_path = "dbfs:/FileStore/data_set.txt"
output_path = "dbfs:/FileStore/"

# COMMAND ----------

schema = StructType(
    [
        StructField("hotel", StringType(), True),
        StructField("is_canceled", BooleanType(), True),
        StructField("lead_time", IntegerType(), True),
        StructField("arrival_date_year", StringType(), True),
        StructField("arrival_date_month", StringType(), True),
        StructField("arrival_date_week_number", StringType(), True),
        StructField("arrival_date_day_of_month", StringType(), True),
        StructField("stays_in_weekend_nights", IntegerType(), True),
        StructField("stays_in_week_nights", IntegerType(), True),
        StructField("adults", IntegerType(), True),
        StructField("children", IntegerType(), True),
        StructField("babies", IntegerType(), True),
        StructField("meal", StringType(), True),
        StructField("country", StringType(), True),
        StructField("market_segment", StringType(), True),
        StructField("distribution_channel", StringType(), True),
        StructField("is_repeated_guest", BooleanType(), True),
        StructField("previous_cancellations", BooleanType(), True),
        StructField("previous_bookings_not_canceled", BooleanType(), True),
        StructField("reserved_room_type", StringType(), True),
        StructField("assigned_room_type", StringType(), True),
        StructField("booking_changes", BooleanType(), True),
        StructField("deposit_type", StringType(), True),
        StructField("agent", StringType(), True),
        StructField("company", StringType(), True),
        StructField("days_in_waiting_list", StringType(), True),
        StructField("customer_type", StringType(), True),
        StructField("adr", StringType(), True),
        StructField("required_car_parking_spaces", StringType(), True),
        StructField("total_of_special_requests", StringType(), True),
        StructField("reservation_status", StringType(), True),
        StructField("reservation_status_date", DateType(), True),
    ]
)

# COMMAND ----------

extract_tour_operator_bookings(input_path, schema, output_path)