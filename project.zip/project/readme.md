# Bookings ETL Application

This is an Apache Spark application that processes bookings data to extract and enrich data related to Tour Operators. 

## Requirements
- Databricks
- Apache Spark version >= 3.5.0
- Python 3.9

### Cluster Config
    "autoscale": {
        "min_workers": 1,
        "max_workers": 4
    },
    "cluster_name": "my-cluster-3",
    "spark_version": "14.3.x-scala2.12
    "node_type_id": "r5d.large",
    "driver_node_type_id": "r5d.large"

### External Libraries
1. Pytest


## Steps to Run
### Piepline
1. Place the input CSV file in the `desired input file path` directory.
2. Set input and output path in booking_etl_notebook
3. Run the booking_etl_notebook

### Unit test
1. Set input and output path in test_booking_etl.py
2. Run the booking_etl_unit_test_notebook to run the unit tests.

## Orchastrate the pipeline
1. Create a workflow in Databricks, and schedule both the etl and notebook as tasks to run them on schedule.

