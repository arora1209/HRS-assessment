import pytest
import sys
from databricks.sdk.runtime import spark

sys.path.append(../)
from src.bookings_etl import extract_tour_operator_bookings

def test_etl_pipeline(spark_session, tmp_path):
   # Prepare input data   
   test_data = [
    ("Resort Hotel", 0, 50, 2024, "January", 2, 10, 2, 5, 2, 1, 0, "BB", "PRT", "Tour Operators", "TA/TO", 0, 0, 1, "A", "A", 0, "No Deposit", "9", "", 0, "Transient", 100.0, 1, 0, "Check-Out", "2024-01-17"),
    ("City Hotel", 1, 100, 2024, "February", 6, 15, 0, 3, 1, 0, 1, "HB", "ESP", "Direct", "Direct", 0, 1, 0, "B", "B", 1, "Refundable", "13", "", 2, "Transient", 150.0, 0, 2, "Canceled", "2024-02-13"),
   ]

   # Define schema
   columns = [
      "hotel", "is_canceled", "lead_time", "arrival_date_year", "arrival_date_month", 
      "arrival_date_week_number", "arrival_date_day_of_month", "stays_in_weekend_nights", 
      "stays_in_week_nights", "adults", "children", "babies", "meal", "country", 
      "market_segment", "distribution_channel", "is_repeated_guest", "previous_cancellations", 
      "previous_bookings_not_canceled", "reserved_room_type", "assigned_room_type", 
      "booking_changes", "deposit_type", "agent", "company", "days_in_waiting_list", 
      "customer_type", "adr", "required_car_parking_spaces", "total_of_special_requests", 
      "reservation_status", "reservation_status_date"
   ] 
   input_df = spark_session.createDataFrame(test_data, columns)

   # Temporary input and output paths   
   input_path = tmp_path / "input.csv"   
   output_path = tmp_path / "output"   
   input_df.write.csv((input_path), header=True)

   # Run ETL pipeline   
   extract_tour_operator_bookings((input_path), (output_path))

   # Validate output   
   output_df = spark.read.parquet((output_path)) 

   output_df_count = output_df.count() 
   assert (
            output_df_count.count() == 1
            ), f"Assertion failed: {output_df_count} != 1"  
   # assert output_df.count() == 1  
   # Only 1 record should be filtered
   assert (
            output_df.filter(output_df["with_family_breakfast"] == "Yes").count() == 1
         ), f"Assertion failed: total families with family breakfast != 1"  
   

   assert output_df.filter(output_df["with_family_breakfast"] == "Yes").count() == 1