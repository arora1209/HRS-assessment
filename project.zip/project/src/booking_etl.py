import os
from databricks.sdk.runtime import spark
from pyspark.sql.functions import col, concat_ws, lit, expr, when

def extract_tour_operator_bookings(input_path, schema, output_path):
    try:
        # Step 1: Read the bookings data
        bookings_df = spark.read.option("header", True).schema(schema).csv(input_path)

        # Step 2: Filter for Tour Operators as Market Segment
        filtered_df = bookings_df.filter(col("market_segment") == "Tour Operators")

        # Step 3: Add extra fields: arrival_date and departure_date
        enriched_df = filtered_df \
            .withColumn("arrival_date", 
                        concat_ws("-", 
                                  col("arrival_date_year"),
                                  col("arrival_date_month"),
                                col("arrival_date_day_of_month"))) \
            .withColumn("departure_date",
                        expr("date_add(arrival_date, stays_in_weekend_nights + stays_in_week_nights)")
                        )

        # Step 4: Add with_family_breakfast field
        enriched_df = enriched_df \
            .withColumn("with_family_breakfast",
                         when((col("children") + col("babies")) > 0,
                               lit("Yes")).otherwise(lit("No")
                                                     )
                               )

        # Step 5: Save the resulting dataset as a Parquet file
        enriched_df.write.mode("overwrite").parquet(output_path)

    except Exception as e:
        print(f"An error occurred during the ETL process: {e}")